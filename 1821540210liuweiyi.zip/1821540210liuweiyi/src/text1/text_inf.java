package text1;

public class text_inf {
}
